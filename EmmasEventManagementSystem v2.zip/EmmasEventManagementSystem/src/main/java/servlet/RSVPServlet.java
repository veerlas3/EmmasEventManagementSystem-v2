package servlet;

import model.Event;
import model.RSVP;
import util.DBUtil;


public class RSVPServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null)
            action = "list";
        try {
            switch (action) {
                case "list":
                    listRSVPs(request, response);
                    break;
                default:
                    listRSVPs(request, response);
                    break;
            }
        } catch (Exception ex) {
            throw new ServletException(ex);
        }
    }

}
