package model;

public class RSVP {
    private int rsvpId;
    private int eventId;
    private String name;
    private int numGuests;

    public int getRsvpId() {
        return rsvpId;
    }
    public void setRsvpId(int rsvpId) {
        this.rsvpId = rsvpId;
    }
    public int getEventId() {
        return eventId;
    }
    public void setEventId(int eventId) {
        this.eventId = eventId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getNumGuests() {
        return numGuests;
    }
    public void setNumGuests(int numGuests) {
        this.numGuests = numGuests;
    }
}
